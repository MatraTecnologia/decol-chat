import * as React from 'react'
import { Loader2Icon } from 'lucide-react'

import { cn } from '@workspace/ui/lib/utils'

const Spinner = ({ className, ...props }: React.ComponentProps<'svg'>) => (
  <Loader2Icon
    role="status"
    aria-label="Loading"
    className={cn('size-4 animate-spin', className)}
    {...props}
  />
)

export { Spinner }
